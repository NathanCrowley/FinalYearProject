# Simple Calulator library

Takes two numbers as inputs and either:
	- add
	- subtract
	- multiply
	- divide
